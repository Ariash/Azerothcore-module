/**
    This plugin can be used for common player customizations
 */

#include "ScriptMgr.h"
#include "Player.h"
#include "Config.h"
#include "Chat.h"
#include "Language.h"


class CustomCommands : public CommandScript
{
public:
    CustomCommands() : CommandScript("CustomCommands") {}

   std::vector<ChatCommand> GetCommands() const override
	{
        static std::vector<ChatCommand> IngameCommandTable =
		{

            { "mall",            SEC_PLAYER,     false,  &HandlemallCommand,      "" },
            { "duel",            SEC_PLAYER,     false,  &HandleduelCommand,      "" }

		};
		return IngameCommandTable;
	}

	static bool HandlemallCommand(ChatHandler * handler, const char * args)
	{
		Player * me = handler->GetSession()->GetPlayer();

		if (me->IsInCombat())
		{
			handler->SendSysMessage(LANG_YOU_IN_COMBAT);
			handler->SetSentErrorMessage(true);
			return false;

		}
		else
		{

			me->TeleportTo(571, 5562.36f, 4668.41f, -135.282f, 2.17789f);
			handler->PSendSysMessage("Welcome to the Mall |cff00ff00");
			return true;
		}

	}

	static bool HandleduelCommand(ChatHandler * handler, const char * args)
	{
		Player * me = handler->GetSession()->GetPlayer();

		if (me->IsInCombat())
		{
			handler->SendSysMessage(LANG_YOU_IN_COMBAT);
			handler->SetSentErrorMessage(true);
			return false;

		}
		else
		{
			me->TeleportTo(0, 4300.65f, -2760.82f, 17.0707f, 3.63972f);
			handler->PSendSysMessage("Welcome to the Duelzone |cff00ff00");

			return true;

		}

	}



};


void AddSC_CustomCommands()
{
     new CustomCommands();
}
