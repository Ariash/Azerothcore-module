void AddSC_CustomCommands();

void AddCustomCommandsScripts() {
    AddSC_CustomCommands();
}